
  # Facebook Ad Mockup (Community)

  This is a code bundle for Facebook Ad Mockup (Community). The original project is available at https://www.figma.com/design/moaPXn4etlBxscqKmQtbA0/Facebook-Ad-Mockup--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
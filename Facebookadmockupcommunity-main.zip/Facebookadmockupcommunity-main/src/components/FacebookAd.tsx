import { MoreHorizontal, ThumbsUp, MessageCircle, Share, Heart, Laugh } from "lucide-react";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function FacebookAd() {
  return (
    <div className="max-w-lg mx-auto bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      {/* Header */}
      <div className="p-3 flex items-start justify-between">
        <div className="flex items-start space-x-3">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=50&h=50&fit=crop&crop=face"
            alt="Brand Logo"
            className="w-10 h-10 rounded-full object-cover"
          />
          <div className="flex-1">
            <div className="flex items-center space-x-1">
              <h3 className="font-semibold text-[15px] text-gray-900">Vanilia Studio Szeged</h3>
              <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                <svg className="w-2.5 h-2.5 text-white fill-current" viewBox="0 0 20 20">
                  <path d="M6.267 9.267l2.4 2.4 5.066-5.066"/>
                </svg>
              </div>
              <span className="text-xs text-gray-500">·</span>
              <span className="text-xs text-gray-500 bg-gray-100 px-1.5 py-0.5 rounded">Sponsored</span>
            </div>
            <div className="flex items-center text-xs text-gray-500 space-x-1">
              <span>2h</span>
              <span>·</span>
              <svg className="w-3 h-3 fill-current" viewBox="0 0 16 16">
                <path d="M8 0C3.6 0 0 3.6 0 8s3.6 8 8 8 8-3.6 8-8-3.6-8-8-8zM8 4c1.1 0 2 .9 2 2 0 .8-.5 1.5-1.2 1.8L8 10.5 7.2 7.8C6.5 7.5 6 6.8 6 6c0-1.1.9-2 2-2z"/>
              </svg>
            </div>
          </div>
        </div>
        <Button variant="ghost" size="sm" className="p-1 h-8 w-8">
          <MoreHorizontal className="w-4 h-4 text-gray-600" />
        </Button>
      </div>

      {/* Ad Copy */}
      <div className="px-3 pb-3">
        <p className="text-[15px] leading-5 text-gray-900">
          🎉Megnyitottunk!🎉 </p>
<p>Szeretsz sütni, vagy kipróbálnád magad? A Vanilia Studioban workshopokon tanulhatsz kenyér-, süti- és desszertkészítést.
            <br></br>
Az első hónapban 15% kedvezmény minden workshopra és foglalkozásra!

        </p>
        <p className="text-[15px] leading-5 text-gray-900 mt-2">
          👉 Foglalj most, és süss velünk!
        </p>
      </div>

      {/* Ad Image */}
      <div className="relative">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1551434678-e076c223a692?w=500&h=300&fit=crop"
          alt="AI automation dashboard"
          className="w-full h-64 object-cover"
        />
        
        
      </div>

      {/* Engagement Stats */}
      <div className="px-3 pt-3">
        <div className="flex items-center justify-between text-sm text-gray-600 pb-2">
          <div className="flex items-center space-x-1">
            <div className="flex -space-x-1">
              <div className="w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center border-2 border-white">
                <ThumbsUp className="w-3 h-3 text-white fill-current" />
              </div>
              <div className="w-5 h-5 bg-red-500 rounded-full flex items-center justify-center border-2 border-white">
                <Heart className="w-3 h-3 text-white fill-current" />
              </div>
              <div className="w-5 h-5 bg-yellow-500 rounded-full flex items-center justify-center border-2 border-white">
                <Laugh className="w-3 h-3 text-white fill-current" />
              </div>
            </div>
            <span>1.2K</span>
          </div>
          <div className="flex space-x-4">
            <span>98 comments</span>
            <span>119 shares</span>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="border-t border-gray-200">
        <div className="flex">
          <Button variant="ghost" className="flex-1 py-3 px-4 hover:bg-gray-50 rounded-none">
            <ThumbsUp className="w-5 h-5 mr-2 text-gray-600" />
            <span className="text-gray-700">Like</span>
          </Button>
          <Button variant="ghost" className="flex-1 py-3 px-4 hover:bg-gray-50 rounded-none">
            <MessageCircle className="w-5 h-5 mr-2 text-gray-600" />
            <span className="text-gray-700">Comment</span>
          </Button>
          <Button variant="ghost" className="flex-1 py-3 px-4 hover:bg-gray-50 rounded-none">
            <Share className="w-5 h-5 mr-2 text-gray-600" />
            <span className="text-gray-700">Share</span>
          </Button>
        </div>
      </div>
    </div>
  );
}
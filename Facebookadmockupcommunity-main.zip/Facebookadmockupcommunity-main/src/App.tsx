import { FacebookAd } from "./components/FacebookAd";

export default function App() {
  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Facebook Ad Preview</h1>
          <p className="text-gray-600">A realistic mockup of a Facebook sponsored post</p>
        </div>
        
        <FacebookAd />
        
        <div className="mt-8 text-center text-sm text-gray-500">
          <p>This is a mockup for demonstration purposes</p>
        </div>
      </div>
    </div>
  );
}